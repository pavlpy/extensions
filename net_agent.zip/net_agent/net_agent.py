import requests
import wget
import socket
import os

class start:
    def __init__(self, addCommand) -> None:
        addCommand("gethtml", self.getHTML)
        addCommand("getfile", self.DownloadFile)
        addCommand("getipname", self.GetIpName)
        addCommand("getip", self.getIP)
        addCommand("ipconfig", self.ipconf)

    def getHTML(self, args):
        r = requests.get(args[0]) #url - ссылка
        html = r.text
        f = open(args[1] + '.html', 'w',encoding="utf-8")
        f.write(html)
        f.close()
    def DownloadFile(self, args):
        wget.download(args[0], args[1])
        print("\n Succes! \n")
    def GetIpName(self):
        h_name = socket.gethostname()
        print("Host Name is:" + h_name)
    def getIP(self, args):
        if len(args) < 1:
            h_name = socket.gethostname()
            IP_addres = socket.gethostbyname(h_name)
            print("Computer IP Address is:" + IP_addres)
        else:
            h_name = args[0]
            IP_addres = socket.gethostbyname(h_name)
            print("Computer IP Address is:" + IP_addres)
    def ipconf(self):
        os.system("ipcofig")