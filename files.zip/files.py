import os
class start:
    def __init__(self, addCommand) -> None:
        self.super = super
        addCommand("ls", self.listfolder)
        addCommand("dir", self.listfolder)
        addCommand("cd", self.cd)
        addCommand("mkdir", self.mkdir)
        addCommand("rmfile", self.rmfile)
        addCommand("rmdir", self.rmdir)
        addCommand("rename", self.rename)
        addCommand("showtxt", self.showtxtfile)
        #addCommand()
        pass
    def listfolder(self, args):
        if len(args) < 1:
            for i in range(len(os.listdir())):
                a = os.listdir()
                print(a[i])
            return
        try:
            for i in range(len(os.listdir(str("".join(args))))):
                a = os.listdir(str("".join(args)))
                print(a[i])
                
        except :
            for i in range(len(os.listdir())):
                a = os.listdir()
                print(a[i])
    def cd(self, args):
        if "".join(args).find(":") != -1:
            os.chdir("".join(args))
        else:
            os.chdir(os.getcwd() + "".join(args))
    def mkdir(self,args):
        os.mkdir("".join(args))
    def rmfile(self, args):
        os.remove("".join(args))
    def rmdir(self, args):
        os.rmdir("".join(args))
    def rename(self,args):
        os.rename(args[1], args[2])
    def showtxtfile(self,file):
        fil = open(file, "r")
        print(fil.read())
        fil.close()
            




                
