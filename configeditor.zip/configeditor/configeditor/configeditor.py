import os
class start:
    def __init__(self, addCommand) -> None:
       self.super = super
       addCommand("reconfigureall", self.createconfig)
       addCommand("addtoconfig", self.addtoconfig)
       addCommand("removeinconfig", self.removeinconfig)
       pass
    def createconfig(self, args):
        print("Reconfiguring . . . .")
        self.additions = os.listdir(os.getcwd() + "\\lib\\")
        self.conf = open("config.txt", "w")
        a = ""
        for i in range(len(self.additions)):
            a = a + self.additions[i] + ","
        self.conf.write(a)
        print("Config file was reconfigured. Closing config file . . . ")
        self.conf.close()
        print("Done!")
    
    def addtoconfig(self, args):
        component = args[0]
        print("Adding component "+ component + ". . . .")
        self.conf = open("config.txt", "a")
        self.conf.write(component + ",")
        self.conf.close()
        print("Done!")

    def removeinconfig(self, args):
        component = args[0]
        print("Removing component " + component + " . . . ")
        self.conf = open("config.txt", "r")
        additions = self.conf.read().split(",")
        try:
            additions.remove(component)
        except Exception:
            print("There is an Exception")
            
        print("The component '" + component + "' was succesfuly removed. Saving changes . . . . ")
        self.conf.close()

        self.conf = open("config.txt","w" )
        a = ""
        for i in range(len(additions)):
            a = a + self.additions[i] + ","
        self.conf.write(a)
        self.conf.close()
        print("Done")
