import time
import zipfile
import shutil
class start:
    def __init__(self, addCommand) -> None:
        self.super = super
        addCommand("unpack", self.unpack)
        addCommand("createzip", self.createfolder)
        pass
    def unpack(self, args):
        filezip = args[0]
        path_to_extract_to = args[1]
        with zipfile.ZipFile(filezip, 'r') as zip_ref:
           zip_ref.extractall(path_to_extract_to)
        print("Unpacking...")
        time.sleep(1.5)
        print("Unpacked!!")
    def createfolder(self, path):
        zip = path[0]
        dir = path[1]
        arhtype = path[2]
        print("making archive, please wait...")
        shutil.make_archive(zip, arhtype, dir)
