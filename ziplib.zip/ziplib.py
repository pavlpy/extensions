import zipfile
class start:
    def __init__(self, addCommand) -> None:
        self.super = super
        addCommand("unpack", self.unpack)
        addCommand("createzip", self.archivecreate)
        pass
    def unpack(self, filezip, path_to_extract_to):
        with zipfile.ZipFile(filezip, 'r') as zip_file:
            zip_file.extractall(path_to_extract_to)
    def archivecreate(self, files, path):
        with zipfile.ZipFile(path, 'w') as zf:
            zf.write(files.split(","))
            zf.close()